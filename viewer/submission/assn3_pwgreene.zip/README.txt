* Code can be complied via the commands given in the assignment for Athena Linux

* I didn’t collaborate with anyone

* No references

* There aren’t any bugs that I’m aware of

* For extra credit, I extended the cloth code to make a new class, GelatinSystem, that is basically a 3D version of the cloth. It consists of a 4x4x4 cube of particles (any more than 4 in each dimension slows down the running on my computer) and it works best with RK4 with h=0.01.